a = range(1,11)
for a in range(1,11):
    print(str(a) +"x3 = " + str(a*3))

range(10,101, 2)
print("")
print("Raket")
x = range(31,0)

for x in range(31):
    print(str(x))

print("Raketlancering")
print("")
print("")
print("Tijden van de dag")
am=range(0,12)
for am in range(0,12):
    print(str(am) + " A.M")
    
pm=range(12,25)
for pm in range(12,24):
    print(str(pm)+ " P.M")


    


pm=range(12,25)


    